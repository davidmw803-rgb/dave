# Swings — live Polymarket window scanner

Drop-in Next.js page that watches Polymarket markets in real time and
highlights the price action in the **last 60s / 30s / 10s before each
5-minute mark**. Built for the buy-early / hit-the-flip-late strategy.

## Install

1. Copy `page.tsx` to `app/dashboard/swings/page.tsx` (or wherever your
   routing fits) in your Next.js project.
2. No new dependencies — uses native `WebSocket`, `fetch`, and React hooks.
3. Visit `/dashboard/swings`.

## How it works

- Connects to `wss://ws-subscriptions-clob.polymarket.com/ws/market` (no auth)
- Subscribes to whatever YES token IDs (`asset_id`s) you add via the input
- Keeps a 10-minute rolling tick buffer per market (mid-price from book +
  last-trade-price events)
- A global countdown bar shows time until the next 5-min mark
- The bar background turns yellow at T-60s, amber at T-30s, red at T-10s
- Each market card shows current price, three window stat rows (60s/30s/10s
  delta + range + tick count), and a sparkline with the windows shaded so
  you can see where the move happened

## Finding asset IDs

The "asset ID" is the long numeric YES token ID for a Polymarket market.
A few ways to get one:

- Browse `polymarket.com`, open the market you care about, and inspect the
  network tab — the WebSocket subscriptions and CLOB API calls reference it
- Use the Gamma API: `GET https://gamma-api.polymarket.com/markets?slug=…`
  and look at the `clobTokenIds` field — index 0 is YES, index 1 is NO
- The companion library `@nevuamarkets/poly-websockets` has helpers for this

## Customization ideas

- **Persist watchlist:** save asset IDs to `localStorage` so they survive
  refreshes. Currently markets reset on reload.
- **Alerts:** trigger a sound or browser notification when the 10s window
  shows a delta above some threshold (your "edge detected" signal).
- **Save windows to Supabase:** snapshot each completed 5-min window's
  60/30/10 stats into `momentum_analysis_runs` (extend the schema) so you
  can backtest whether late-window swings predict resolution.
- **Negative-risk markets:** for multi-outcome events, watch all token IDs
  in one card and show the simplex (they should sum to ~1).

## Known limits

- Browser WebSocket reconnects on drop, but a long disconnect = gaps in your
  tick buffer. For real backtesting, persist ticks server-side.
- The "mid price" from book events isn't the same as last trade price, so
  the sparkline mixes two slightly different signals. Fine for spotting
  swings, less fine for precise PnL.
- No order entry — this is a scanner only. By design; trade through the
  Polymarket UI.
