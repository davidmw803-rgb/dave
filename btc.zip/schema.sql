-- Supabase schema for momentum persistence analysis results.
-- Run this in the Supabase SQL editor once before using --save.

create table if not exists momentum_analysis_runs (
    id              bigserial primary key,
    run_at          timestamptz not null default now(),
    source          text not null,               -- 'csv' | 'yfinance' | 'supabase'
    label           text not null,               -- human-readable identifier

    -- Sample stats
    n_candles               integer not null,
    n_transitions           integer not null,
    base_rate_up            double precision,
    base_rate_down          double precision,

    -- Conditional probabilities
    p_up_given_prev_up      double precision,
    p_down_given_prev_down  double precision,
    hit_rate_follow_prev    double precision,

    -- Transition counts
    uu                      integer,
    ud                      integer,
    du                      integer,
    dd                      integer,

    -- Runs
    longest_up_run          integer,
    longest_down_run        integer,

    -- Strategy metrics
    strategy_avg_pnl_per_bet double precision,
    strategy_win_rate        double precision,
    strategy_avg_win         double precision,
    strategy_avg_loss        double precision,
    strategy_expectancy      double precision
);

create index if not exists idx_momentum_runs_run_at on momentum_analysis_runs (run_at desc);
create index if not exists idx_momentum_runs_label  on momentum_analysis_runs (label);

-- OPTIONAL: if you want to store OHLC inputs in Supabase too, here's a
-- suggested shape. Your scanner may already have its own table.
--
-- create table if not exists ohlc_candles (
--     id           bigserial primary key,
--     symbol       text not null,
--     timestamp    timestamptz not null,
--     open         double precision not null,
--     high         double precision,
--     low          double precision,
--     close        double precision not null,
--     volume       double precision,
--     unique (symbol, timestamp)
-- );
-- create index if not exists idx_ohlc_symbol_ts on ohlc_candles (symbol, timestamp);
